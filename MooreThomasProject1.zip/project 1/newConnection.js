window.onload = function () {
    document.getElementById("create_new").onclick = function () {
        window.location.href = "connections.html";
    }
}