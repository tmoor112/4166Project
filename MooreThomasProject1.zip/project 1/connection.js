window.onload = function () {
    document.getElementById("update").onclick = function () {
        window.location.href = "connections.html";
    }
    document.getElementById("delete").onclick = function () {
        window.location.href = "connections.html";
    }
    
}